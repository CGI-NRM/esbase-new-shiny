# Process for reporting security vulnerabilities

For reporting a security vulnerability, please e-mail the package maintainer at krlmlr+r@mailbox.org for further instructions.
Do not include confidential information in the e-mail.
