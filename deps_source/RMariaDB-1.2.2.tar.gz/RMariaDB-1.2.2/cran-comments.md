RMariaDB 1.2.2

## Cran Repository Policy

- [x] Reviewed CRP last edited 2022-05-03.

## R CMD check results

- [x] Checked locally, R 4.1.3
- [x] Checked on CI system, R 4.2.0
- [x] Checked on win-builder, R devel

## Current CRAN check results

- [x] Checked on 2022-06-19, problems found: https://cran.r-project.org/web/checks/check_results_RMariaDB.html
- [x] NOTE: r-release-macos-arm64, r-release-macos-x86_64, r-oldrel-macos-arm64, r-oldrel-macos-x86_64, r-oldrel-windows-ix86+x86_64: Large binary.
